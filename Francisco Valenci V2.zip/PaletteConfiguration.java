import javax.swing.*;

public class PaletteConfiguration extends JTable {

}
