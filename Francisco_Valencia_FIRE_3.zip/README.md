# Chimenea_V2
Creamos un fuego basado en pixeles con temperaturas.
Factorizando al modelo MVC
Aplicando el patron de diseño DTO

## Cosas por hacer

- Clase TemperatureConfigurations - Hijos de JPanel
- Crear un nuevo firemodel cada vez que cambie altura y ancho del fuego
- Hacer la interfaz mas bonita
- Hago que stop detenga 