public class TemperatureConfiguration {

}
