public class main {
    public static void main (String args[]){
        FireController fire = new FireController();
        fire.main();
    }
}